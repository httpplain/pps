TCP Flood through socks5 proxies.
Proxies can be found here: https://checkerproxy.net/

Coded by @winfaredev | Telegram: t.me/ddosscriptsleaks