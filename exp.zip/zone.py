import os
import requests
import re
import urllib3
import threading
import time
import random
import bs4

requests.urllib3.disable_warnings()

# output file
domain_file = "list.txt"

def banner():
    print("""
zone
    """)

def checkOutput():

    global domain_file

    if os.path.exists(domain_file):
        os.remove(domain_file)

def grabDomain(pages):

    global domain_file

    try:
        
        # mirror list
        mirror_list = [
            "https://defacermirror.com/archive.php?page=",
            "https://defacermirror.com/special.php?page=",
            "https://defacer.net/archive/",
            "https://defacer.net/special/",
            "https://mirror-h.org/archive/page/",            
            "https://haxor.id/archive?page=",            
            "https://haxor.id/archive/special?page=",
        ]
        for mirror in mirror_list:

            page = pages + 1
            url = f"{mirror}{page}"
            user_agent = generate_user_agent()  # generates a random user agent
            header = {"User-Agent": user_agent}
            response = requests.get(url, headers=header, timeout=10, verify=False)

            if "https://defacermirror.com/archive.php?page=" in url:
                grab_domain = re.findall('target="_blank">(.*?)</a></td>', response.text)

                for domain in grab_domain:
                    domain = domain.split("/")
                    save = open(domain_file, "a")
                    save.write(f"{domain[0]}\n")
                    save.close()
                    print(domain[0])                                             

            elif "https://defacermirror.com/special.php?page=" in url:
                grab_domain = re.findall('target="_blank">(.*?)</a></td>', response.text)

                for domain in grab_domain:
                    domain = domain.split("/")
                    save = open(domain_file, "a")
                    save.write(f"{domain[0]}\n")
                    save.close()
                    print(domain[0])                 
                                                                                                                                                                     
                    
            elif "https://defacer.net/archive/" in url:
                grab_domain = re.findall("' /></td><td></td><td><?a?.+'>(.*?)</a></td>", response.text)

                for domain in grab_domain:
                    domain = domain.split("/")
                    save = open(domain_file, "a")
                    save.write(f"{domain[0]}\n")
                    save.close()
                    print(domain[0])                 

            elif "https://defacer.net/special/" in url:
                grab_domain = re.findall("' /></td><td>★</td><td><?a?.+'>(.*?)</a></td>", response.text)

                for domain in grab_domain:
                    domain = domain.split("/")
                    save = open(domain_file, "a")
                    save.write(f"{domain[0]}\n")
                    save.close()
                    print(domain[0])
                    
            elif "https://mirror-h.org/archive/page/" in url:
                grab_domain = re.findall('<td style="word-break: break-word;white-space: normal;min-width: 300px;"><?a?.+\>(.*?)</a></td>', response.text)
                
                for domain in grab_domain:
                    domain = domain.split("/")
                    save = open(domain_file, "a")
                    save.write(f"{domain[2]}\n")
                    save.close()
                    print(domain[2])             

            elif "https://haxor.id/archive?page=" in url:
                grab_domain = re.findall('<td><a rel="nofollow" title="(.*?)"', response.text)
                
                for domain in grab_domain:
                    domain = domain.split("/")
                    save = open(domain_file, "a")
                    save.write(f"{domain[0]}\n")
                    save.close()
                    print(domain[0])                                                                                     
                    
            elif "https://haxor.id/archive/special?page=" in url:
                grab_domain = re.findall('<td><a rel="nofollow" title="(.*?)"', response.text)
                
                for domain in grab_domain:
                    domain = domain.split("/")
                    save = open(domain_file, "a")
                    save.write(f"{domain[0]}\n")
                    save.close()
                    print(domain[0])                                                                                                                                                       
            
            else:
                pass
                
    except:
        pass

def generate_user_agent():
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.246",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36",
    ]
    return random.choice(user_agents)

if __name__ == "__main__":
    banner()
    checkOutput()

    total_pages = int(input("Total pages: "))
    print("\n")

    threads = []
    for x in range(0, total_pages):
        pages = x
        grab = threading.Thread(target=grabDomain, args=(pages,))
        threads.append(grab)
    
    for grab in threads:
        grab.start()

    for grab in threads:
        grab.join()