import clc from 'cli-color'

export const notice = ({ message = '', type = 'warning' }) => {
    switch (type) {
        case 'warning':
            break;
        case 'error':
            break;
        case 'info':
            break;
        case 'success':
            break;
        default:
            break;
    }
    return true
}


export function slugify(text) {
    text = String(text)
    return text
        .toUpperCase()
        .toLowerCase()
        .normalize('NFD')
        .trim()
        .replace(/\s+/g, '-')
        .replace(/[^\w\-]+/g, '');
}

export const sleep = (ms) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve()
        }, ms);
    })
}